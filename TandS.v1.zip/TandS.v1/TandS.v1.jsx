// Adobe Illustrator Script to create 2 tints and 2 shades for each selected color (RGB and CMYK)

// Ensure something is selected
if (app.selection.length > 0) {
    // Get the selected items
    var selectedItems = app.selection;

    // Loop through each selected item
    for (var i = 0; i < selectedItems.length; i++) {
        var item = selectedItems[i];

        // Check if the item has a fill color and is a path item
        if (item.filled && item.typename == "PathItem") {
            // Get the original color
            var originalColor = item.fillColor;

            // Define a base name for the swatch group
            var baseName = "Color_" + (i + 1); // default name if no name is provided
            
            // Check if swatch exists and use its name if available
            if (item.fillColor.typename == "SpotColor" && item.fillColor.spot) {
                baseName = item.fillColor.spot.name;
            }

            // Handle RGB and CMYK colors
            if (originalColor.typename == "RGBColor" || originalColor.typename == "CMYKColor") {
                // Create tints and shades
                var tintsShades = createTintsAndShades(originalColor);

                // Apply each tint and shade as a new swatch with a grouped name
                addSwatch(originalColor, baseName); // Original color swatch
                addSwatch(tintsShades[0], baseName + "_Tint1");
                addSwatch(tintsShades[1], baseName + "_Tint2");
                addSwatch(tintsShades[2], baseName + "_Shade1");
                addSwatch(tintsShades[3], baseName + "_Shade2");
            }
        }
    }
}

// Function to create two tints and two shades of a given color
function createTintsAndShades(color) {
    var colors = [];

    // Check if color is RGB or CMYK, and create tints/shades accordingly
    if (color.typename == "RGBColor") {
        // Lighter tints
        colors.push(createRGBTint(color, 0.8));  // 20% lighter
        colors.push(createRGBTint(color, 0.6));  // 40% lighter

        // Darker shades
        colors.push(createRGBShade(color, 0.8)); // 20% darker
        colors.push(createRGBShade(color, 0.6)); // 40% darker

    } else if (color.typename == "CMYKColor") {
        // Lighter tints
        colors.push(createCMYKTint(color, 0.8));  // 20% lighter
        colors.push(createCMYKTint(color, 0.6));  // 40% lighter

        // Darker shades by increasing only the black (K) channel
        colors.push(createCMYKShade(color, 0.2)); // Increase black by 20%
        colors.push(createCMYKShade(color, 0.4)); // Increase black by 40%
    }

    return colors;
}

// Function to create a tint by lightening an RGB color
function createRGBTint(color, factor) {
    var tintedColor = new RGBColor();
    tintedColor.red = color.red + (255 - color.red) * factor;
    tintedColor.green = color.green + (255 - color.green) * factor;
    tintedColor.blue = color.blue + (255 - color.blue) * factor;
    return tintedColor;
}

// Function to create a shade by darkening an RGB color
function createRGBShade(color, factor) {
    var shadedColor = new RGBColor();
    shadedColor.red = color.red * factor;
    shadedColor.green = color.green * factor;
    shadedColor.blue = color.blue * factor;
    return shadedColor;
}

// Function to create a tint by lightening a CMYK color
function createCMYKTint(color, factor) {
    var tintedColor = new CMYKColor();
    tintedColor.cyan = color.cyan * factor;
    tintedColor.magenta = color.magenta * factor;
    tintedColor.yellow = color.yellow * factor;
    tintedColor.black = color.black * factor;
    return tintedColor;
}

// Function to create a shade by increasing only the black component in a CMYK color
function createCMYKShade(color, increase) {
    var shadedColor = new CMYKColor();
    shadedColor.cyan = color.cyan;
    shadedColor.magenta = color.magenta;
    shadedColor.yellow = color.yellow;
    shadedColor.black = Math.min(100, color.black + increase * 100); // Increase black component
    return shadedColor;
}

// Function to add a color to the swatches panel with a specified name
function addSwatch(color, name) {
    var swatch = app.activeDocument.swatches.add();
    swatch.color = color;
    swatch.name = name;
    return swatch;
}
